(() => {
    const Filters = (props) => {
        let chooseAuthor = (clickEvent) => {
            props.updateFormState({
                authorName: clickEvent.target.value,});
        }

        let recommendable = (clickEvent) => {
            props.updateFormState({
                doRecommend: clickEvent.target.checked,});
        }

        let chooseGenre = (clickEvent) => {
            props.updateFormState({
                selectedGenre: clickEvent.target.value,
            });
        }

        let searchBook = (inputEvent) => {
            props.updateFormState({
                searchBook: inputEvent.target.value,
            });
        }
        return (
            <React.Fragment>
            <p>
                <h2 id = "larger" className = "white">Raw Data (With Filters)</h2>
            </p>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-1'></div>
                    <div className='col-md-3'>
                        <b>Author Name   </b>
                        <select onChange={chooseAuthor}>
                            <option value=''>All Authors</option>
                            <option value='Brandon Sanderson'>Brandon Sanderson</option>
                            <option value='Stephen King'>Stephen King</option>
                            <option value='Niel Gaiman'>Niel Gaiman</option>
                            <option value='Terry Prachett'>Terry Prachett</option>
                            <option value='Pierce Brown'>Pierce Brown</option>
                            <option value='Charlie Higson'>Charlie Higson</option>
                            <option value='Neal Shusterman'>Neal Shusterman</option>
                            <option value='Hirohiko Araki'>Hirohiko Araki</option>
                            <option value='Wizards RPG Team'>Wizards RPG Team</option>
                            <option value='Matthew Mercer'>Matthew Mercer</option>
                            <option value='Rutger Bregman'>Rutger Bregman</option>
                            <option value='Sayaka Murata'>Sayaka Murata</option>
                            <option value='Kotaro Isaka'>Kotaro Isaka</option>
                            <option value='Cressida Cowell'>Cressida Cowell</option>
                            <option value='Cormac McCarthy'>Cormac McCarthy</option>
                            <option value='Anthony Bourdain'>Anthony Bourdain</option>
                            <option value='Harlan Ellison'>Harlan Ellison</option>
                             <option value='Jim Gaffigan'>Jim Gaffigan</option>
                            <option value='Donna Gephart'>Donna Gephart</option>
                            <option value='Drew Magary'>Drew Magary</option>
                            <option value='Scott McCloud'>Scott McCloud</option>
                            <option value='David Munoz'>David Munoz</option>
                            <option value='Jason Reynolds'>Jason Reynolds</option>
                            <option value='Ibram X. Kendi'>Ibram X. Kendi</option>
                            <option value='&'>Multiple Authors</option>
                        </select>
                    </div>
                    <div className='col-md-2'>
                    <b>Search Book</b>
                    <input
                        type='text'
                        placeholder='Enter book name'
                        value={props.searchBook}
                        onChange={searchBook}
                    />
                    </div>
                    <div className='col-md-2'>
                        <b>Genre   </b>
                        <select onChange={chooseGenre}>
                            <option value=''>All Genres</option>
                            <option value='Fantasy'>Fantasy</option>
                            <option value='Horror'>Horror</option>
                            <option value='SciFi'>SciFi</option>
                            <option value='Western'>Western</option>
                            <option value='Non-Fiction'>Non-Fiction</option>
                            <option value='Rulebook'>Rulebook</option>
                            <option value='Drama'>Drama</option>
                            <option value='Thriller'>Thriller</option>
                            <option value='Manga'>Manga</option>
                            <option value='/'>Multiple Genres</option>
                        </select>
                    </div>
                    <div className='col-md-2'>
                        <b>Recommended   </b>
                        <input type='checkbox' onChange={recommendable} />
                    </div>
                    <div>
                        <textarea name="readingList" rows="1" cols="50">
                            Gabes Most Recommended:
                            If you want to read a book about an Autistic Japanese woman, you should check out Convenience Store Woman.
                            If you want a book about a kid raised by ghosts, you should check out The Graveyard Book. 
                            If you want a horror book about vampires, you should check out 'Salem's Lot. 
                            If you want to read an Epic Fantasy series, you should check out The Stormlight Archives.
                        </textarea>
                    </div>
                    <div className='col-md-3'></div>
                    <div className='col-md-1'></div>
                </div>
                <div className='row'>
                    <div className='col-md-1'></div>
                    <div className='col-md-3'></div>
                    <div className='col-md-2'></div>
                    <div className='col-md-3'></div>
                    <div className='col-md-2'></div>
                    <div className='col-md-1'></div>
                </div>
            </div>
        </React.Fragment>
        );
    }

    const DataTable = (props) => {
        return (
            <div className="table-responsive">
                <table className="table">
                    <tbody>
                        <tr>
                            <th>Book</th>
                            <th>Author</th>
                            <th>Medium</th>
                            <th>Genre</th>
                            <th>Page Count</th>
                            <th>Rating</th>
                            <th>Recommend</th>
                        </tr>
                        {props.dataToDisplay.map((row, i) => {
                            return (
                                <tr key={i}>
                                    <td>{row.Book}</td>
                                    <td>{row.Author}</td>
                                    <td>{row.Medium}</td>
                                    <td>{row.Genre}</td>
                                    <td>{row.PageCount}</td>
                                    <td>{row.Rating}</td>
                                    <td>{row.Recommend ? 'Yes' : 'No'}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        );
    }

    class ReactDataTable extends React.Component {
        constructor(props) {
            super(props);

            this.originalData = props.originalData;

            this.state = {
                authorName: '',
                doRecommend: false,
                selectedGenre: '',
                searchBook: '',
            };

            this.updateFormState = this.updateFormState.bind(this);

        }

        updateFormState(specification) {
            this.setState(specification);
        }


        render() {
            let filteredData = this.originalData;

            if (this.state.authorName !== '') {
                filteredData = filteredData.filter((row) => {
                    return row.Author.toLowerCase().includes(this.state.authorName.toLowerCase());
                });
            }
            if (true === this.state.doRecommend) {
                filteredData = filteredData.filter((row) => {
                    return row.Recommend === true
            });
            }

            if (this.state.selectedGenre !== '') {
                filteredData = filteredData.filter((row) => {
                    return row.Genre.toLowerCase().includes(this.state.selectedGenre.toLowerCase());
                });
            }

            if (this.state.searchBook !== '') {
                filteredData = filteredData.filter((row) => {
                    // Case-insensitive search
                    return row.Book.toLowerCase().includes(this.state.searchBook.toLowerCase());
                });
            }
            
            return (
                <React.Fragment>
                    <Filters
                        authorName={this.state.authorName}
                        doRecommend={this.state.doRecommend}
                        updateFormState={this.updateFormState}

                    />
            
                    <hr />
            
                    <DataTable
                        dataToDisplay={filteredData}
                    />
                </React.Fragment>
            );
        }
    }
    const bookData = [
        {
            "Book": "Scythe",
            "Author": "Neal Shusterman",
            "Medium": "Physical",
            "Genre": "SciFi",
            "PageCount": "448",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "The Thunderhead",
            "Author": "Neal Shusterman",
            "Medium": "Digital",
            "Genre": "SciFi",
            "PageCount": "512",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "The Toll",
            "Author": "Neal Shusterman",
            "Medium": "Digital",
            "Genre": "SciFi",
            "PageCount": "640",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "The Way of Kings",
            "Author": "Brandon Sanderson",
            "Medium": "Audio",
            "Genre": "Fantasy",
            "PageCount": "1007",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Way of Kings",
            "Author": "Brandon Sanderson",
            "Medium": "Audio",
            "Genre": "Fantasy",
            "PageCount": "1087",
            "Rating": 9,
            "Recommend": true
        },
        {
            "Book": "Oathbringer",
            "Author": "Brandon Sanderson",
            "Medium": "Audio",
            "Genre": "Fantasy",
            "PageCount": "1248",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "Rhythm of War",
            "Author": "Brandon Sanderson",
            "Medium": "Audio",
            "Genre": "Fantasy",
            "PageCount": "1232",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "The Long Walk",
            "Author": "Stephen King",
            "Medium": "Digital",
            "Genre": "Horror",
            "PageCount": "384",
            "Rating": 10,
            "Recommend": false
        },
        {
            "Book": "Final Empire",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "669",
            "Rating": 9,
            "Recommend": true
        },
        {
            "Book": "Well of Ascension",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "796",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Hero of Ages",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "760",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "Guards! Guards!",
            "Author": "Terry Prachett",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "416",
            "Rating": 9,
            "Recommend": true
        },
        {
            "Book": "Monstrous Regiment",
            "Author": "Terry Prachett",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "464",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Elantris",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "638",
            "Rating": 6.5,
            "Recommend": true
        },
        {
            "Book": "Tress of the Emerald Sea",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "384",
            "Rating": 9,
            "Recommend": true
        },
        {
            "Book": "The Frugal Wizards Handbook for Surviving Medieval England",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy/SciFi",
            "PageCount": "384",
            "Rating": 4.5,
            "Recommend": false
        },
        {
            "Book": "Yumi and the Nightmare Painter",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "479",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "Bullet Train",
            "Author": "Kotaro Isaka",
            "Medium": "Digital",
            "Genre": "Thriller",
            "PageCount": "432",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "Convenience Store Woman",
            "Author": "Sayaka Murata",
            "Medium": "Digital",
            "Genre": "Drama",
            "PageCount": "160",
            "Rating": 10,
            "Recommend": true
        },
        {
            "Book": "The Color of Magic",
            "Author": "Terry Prachett",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "288",
            "Rating": 7,
            "Recommend": true
        },
        {
            "Book": "No Country for Old Men",
            "Author": "Cormac McCarthy",
            "Medium": "Digital",
            "Genre": "Western",
            "PageCount": "320",
            "Rating": 7.5,
            "Recommend": true
        },
        {
            "Book": "Alloy of Law",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy/Western",
            "PageCount": "336",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Shadows of Self",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy/Western",
            "PageCount": "383",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "The Bands of Mourning",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy/Western",
            "PageCount": "448",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "The Lost Metal",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy/Western",
            "PageCount": "528",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Steel Ball Run",
            "Author": "Hirohiko Araki",
            "Medium": "Digital",
            "Genre": "Western/Manga",
            "PageCount": "95 Chapters",
            "Rating": 10,
            "Recommend": true
        },
        {
            "Book": "JoJolion",
            "Author": "Hirohiko Araki",
            "Medium": "Digital",
            "Genre": "Drama/Manga",
            "PageCount": "110 Chapters",
            "Rating": 7.5,
            "Recommend": true
        },
        {
            "Book": "Explorers Guide to Wildmount",
            "Author": "Matthew Mercer",
            "Medium": "Physical",
            "Genre": "Rulebook",
            "PageCount": "304",
            "Rating": 7,
            "Recommend": true
        },
        {
            "Book": "Tal'Dorei Reborn",
            "Author": "Matthew Mercer",
            "Medium": "Physical",
            "Genre": "Rulebook",
            "PageCount": "280",
            "Rating": 7.5,
            "Recommend": true
        },
        {
            "Book": "Tasha's Cauldron of Everything",
            "Author": "Wizards RPG Team",
            "Medium": "Physical",
            "Genre": "Rulebook",
            "PageCount": "192",
            "Rating": 7.5,
            "Recommend": true
        },
        {
            "Book": "Curse of Strahd",
            "Author": "Wizards RPG Team",
            "Medium": "Digital",
            "Genre": "Rulebook/Horror",
            "PageCount": "256",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "Stone Ocean",
            "Author": "Hirohiko Araki",
            "Medium": "Digital",
            "Genre": "Thriller/Manga",
            "PageCount": "158 Chapters",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "How to Train Your Dragon",
            "Author": "Cressida Cowell",
            "Medium": "Audio",
            "Genre": "Fantasy",
            "PageCount": "256",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "Dad is Fat",
            "Author": "Jim Gaffigan",
            "Medium": "Audio",
            "Genre": "Non-Fiction",
            "PageCount": "288",
            "Rating": 7,
            "Recommend": true
        },
        {
            "Book": "Someone Could Get Hurt",
            "Author": "Drew Magary",
            "Medium": "Audio",
            "Genre": "Non-Fiction",
            "PageCount": "256",
            "Rating": 7.5,
            "Recommend": true
        },
        {
            "Book": "Fairy Tale",
            "Author": "Stephen King",
            "Medium": "Digital",
            "Genre": "Fantasy/Horror",
            "PageCount": "608",
            "Rating": 6,
            "Recommend": false
        },
        {
            "Book": "Pet Sematary",
            "Author": "Stephen King",
            "Medium": "Digital",
            "Genre": "Horror",
            "PageCount": "416",
            "Rating": 10,
            "Recommend": true
        },
        {
            "Book": "Graveyard Shift",
            "Author": "Stephen King",
            "Medium": "Physical",
            "Genre": "Horror",
            "PageCount": "384",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "'Salem's Lot",
            "Author": "Stephen King",
            "Medium": "Digital",
            "Genre": "Horror",
            "PageCount": "672",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "Stamped: Racism, Anti-Racism, and You",
            "Author": "Ibram X. Kendi & Jason Reynolds",
            "Medium": "Audio",
            "Genre": "Non-Fiction",
            "PageCount": "320",
            "Rating": 10,
            "Recommend": true
        },
        {
            "Book": "American Gods",
            "Author": "Niel Gaiman",
            "Medium": "Audio",
            "Genre": "Fantasy",
            "PageCount": "560",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "The Graveyard Book",
            "Author": "Niel Gaiman",
            "Medium": "Audio",
            "Genre": "Fantasy",
            "PageCount": "304",
            "Rating": 10,
            "Recommend": true
        },
        {
            "Book": "Kitchen Confidential: Adventures in the Cullinary Underbelly",
            "Author": "Anthony Bourdain",
            "Medium": "Audio",
            "Genre": "Non-Fiction",
            "PageCount": "352",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Emperors Soul",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "176",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "Good Omens",
            "Author": "Niel Gaiman & Terry Prachett",
            "Medium": "Audio",
            "Genre": "Fantasy",
            "PageCount": "400",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "Utopia for Realists: The Case for a Universal Basic Income, Open Borders, and a 15-hour Workweek",
            "Author": "Rutger Bregman",
            "Medium": "Physical",
            "Genre": "Non-Fiction",
            "PageCount": "336",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Understanding Comics",
            "Author": "Scott McCloud",
            "Medium": "Physical",
            "Genre": "Non-Fiction",
            "PageCount": "224",
            "Rating": 9,
            "Recommend": true
        },
        {
            "Book": "Les Manoir Des Murmures",
            "Author": "David Munoz",
            "Medium": "Physical",
            "Genre": "Horror",
            "PageCount": "184",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "The Sandman",
            "Author": "Niel Gaiman",
            "Medium": "Physical",
            "Genre": "Fantasy/Horror",
            "PageCount": "328",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "White Sand",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "480",
            "Rating": 5.5,
            "Recommend": false
        },
        {
            "Book": "Lily and Dunkin",
            "Author": "Donna Gephart",
            "Medium": "Physical",
            "Genre": "Drama",
            "PageCount": "352",
            "Rating": 9.5,
            "Recommend": true
        },
        {
            "Book": "Warbreaker",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy",
            "PageCount": "592",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "The Sunlit Man",
            "Author": "Brandon Sanderson",
            "Medium": "Digital",
            "Genre": "Fantasy/SciFi",
            "PageCount": "448",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Red Rising",
            "Author": "Pierce Brown",
            "Medium": "Digital",
            "Genre": "SciFi",
            "PageCount": "382",
            "Rating": 7.5,
            "Recommend": true
        },
        {
            "Book": "Golden Son",
            "Author": "Pierce Brown",
            "Medium": "Digital",
            "Genre": "SciFi",
            "PageCount": "464",
            "Rating": 8.5,
            "Recommend": true
        },
        {
            "Book": "Morning Star",
            "Author": "Pierce Brown",
            "Medium": "Digital",
            "Genre": "SciFi",
            "PageCount": "518",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "Iron Gold",
            "Author": "Pierce Brown",
            "Medium": "Digital",
            "Genre": "SciFi",
            "PageCount": "596",
            "Rating": 7,
            "Recommend": true
        },
        {
            "Book": "The Enemy",
            "Author": "Charlie Higson",
            "Medium": "Digital",
            "Genre": "Horror",
            "PageCount": "440",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "Getting Rid of Mister Kitchen",
            "Author": "Charlie Higson",
            "Medium": "Digital",
            "Genre": "Thriller",
            "PageCount": "220",
            "Rating": 9,
            "Recommend": true
        },
        {
            "Book": "The Dead",
            "Author": "Charlie Higson",
            "Medium": "Digital",
            "Genre": "Horror",
            "PageCount": "480",
            "Rating": 8,
            "Recommend": true
        },
        {
            "Book": "I Have No Mouth, and I Must Scream",
            "Author": "Harlan Ellison",
            "Medium": "Audio",
            "Genre": "Horror",
            "PageCount": "13",
            "Rating": 9,
            "Recommend": true
        }
    ];


    const container = document.getElementById('react-data-table');
    const root = ReactDOM.createRoot(container);
    root.render(<ReactDataTable originalData={bookData} />);
})();